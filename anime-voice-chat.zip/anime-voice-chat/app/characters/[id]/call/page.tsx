"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import type { Character } from "@/lib/types";
import VoiceButton from "@/components/VoiceButton";

type CallState = "idle" | "listening" | "thinking" | "speaking" | "error";

export default function CallPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [character, setCharacter] = useState<Character | null>(null);
  const [state, setState] = useState<CallState>("idle");
  const [lastLine, setLastLine] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    fetch(`/api/characters/${id}`)
      .then((r) => r.json())
      .then((data) => setCharacter(data.character));
  }, [id]);

  async function handleRecorded(blob: Blob) {
    setError(null);
    setState("thinking");
    try {
      const form = new FormData();
      form.append("audio", blob, "message.webm");
      const sttRes = await fetch("/api/stt", { method: "POST", body: form });
      const sttData = await sttRes.json();
      if (!sttRes.ok) throw new Error(sttData.error);
      if (!sttData.text?.trim()) {
        setState("idle");
        return;
      }

      const chatRes = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ characterId: id, text: sttData.text }),
      });
      const chatData = await chatRes.json();
      if (!chatRes.ok) throw new Error(chatData.error);
      setLastLine(chatData.reply.content);

      const ttsRes = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ characterId: id, text: chatData.reply.content }),
      });
      if (!ttsRes.ok) throw new Error((await ttsRes.json()).error);
      const audioBlob = await ttsRes.blob();
      const url = URL.createObjectURL(audioBlob);

      setState("speaking");
      const audio = new Audio(url);
      audioRef.current = audio;
      audio.onended = () => setState("idle");
      await audio.play();
    } catch (err: any) {
      setError(err.message || "Something went wrong");
      setState("error");
    }
  }

  function endCall() {
    audioRef.current?.pause();
    router.push(`/characters/${id}/chat`);
  }

  if (!character) {
    return <main className="p-14 text-muted">Connecting…</main>;
  }

  const statusText: Record<CallState, string> = {
    idle: "Tap the mic and talk",
    listening: "Listening…",
    thinking: `${character.name} is thinking…`,
    speaking: `${character.name} is speaking…`,
    error: "Something interrupted the call",
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-between px-6 py-10 bg-ink">
      <Link href={`/characters/${id}/chat`} className="self-start text-sm text-muted hover:text-mist">
        ← Back to chat
      </Link>

      <div className="flex flex-col items-center">
        <div className="relative">
          {(state === "speaking" || state === "listening") && <div className="call-ring" />}
          {character.image_url ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={character.image_url}
              alt={character.name}
              className="relative h-44 w-44 rounded-full object-cover border-2 border-white/10"
            />
          ) : (
            <div className="relative h-44 w-44 rounded-full bg-panel2" />
          )}
        </div>

        <h1 className="font-display text-2xl font-bold mt-6">{character.name}</h1>
        <p className="text-muted text-sm mt-1">{statusText[state]}</p>

        {lastLine && state !== "idle" && (
          <p className="mt-4 max-w-sm text-center text-sm text-mist/80 italic">
            &ldquo;{lastLine}&rdquo;
          </p>
        )}
        {error && <p className="mt-3 text-sm text-signal">{error}</p>}
      </div>

      <div className="flex items-center gap-6 pb-6">
        <button
          onClick={endCall}
          className="h-14 w-14 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20"
          aria-label="End call"
        >
          <PhoneOffIcon />
        </button>

        <div className="scale-150">
          <VoiceButton onRecorded={handleRecorded} disabled={state === "thinking" || state === "speaking"} />
        </div>
      </div>
    </main>
  );
}

function PhoneOffIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M4 4l16 16M10.5 10.5c-.7-.7-1-1.6-.8-2.3l.4-1.6a1 1 0 0 0-.6-1.2L6.9 4.6a1 1 0 0 0-1.2.4c-1 1.5-1.2 3.6-.4 5.7 1 2.8 3 5.6 5.6 7.6l-.9.9"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
    </svg>
  );
}
