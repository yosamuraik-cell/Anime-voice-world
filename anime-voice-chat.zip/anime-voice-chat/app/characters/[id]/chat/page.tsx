"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import type { Character, Message } from "@/lib/types";
import ChatBubble from "@/components/ChatBubble";
import VoiceButton from "@/components/VoiceButton";

export default function ChatPage() {
  const { id } = useParams<{ id: string }>();
  const [character, setCharacter] = useState<Character | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch(`/api/characters/${id}`)
      .then((r) => r.json())
      .then((data) => {
        setCharacter(data.character);
        setMessages(data.messages || []);
      });
  }, [id]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  async function sendText(text: string) {
    if (!text.trim() || busy) return;
    setBusy(true);
    setError(null);
    setMessages((m) => [
      ...m,
      { id: "temp-" + Date.now(), character_id: id, role: "user", content: text, created_at: "" },
    ]);
    setInput("");

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ characterId: id, text }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setMessages((m) => [...m.filter((mm) => !mm.id.startsWith("temp-")), data.reply]);
      // Refetch to also pick up the persisted user message with a real id.
      const full = await fetch(`/api/characters/${id}`).then((r) => r.json());
      setMessages(full.messages);
      playReply(data.reply.content);
    } catch (err: any) {
      setError(err.message || "Something went wrong");
    } finally {
      setBusy(false);
    }
  }

  async function handleVoiceMessage(blob: Blob) {
    setBusy(true);
    setError(null);
    try {
      const form = new FormData();
      form.append("audio", blob, "message.webm");
      const sttRes = await fetch("/api/stt", { method: "POST", body: form });
      const sttData = await sttRes.json();
      if (!sttRes.ok) throw new Error(sttData.error);
      if (!sttData.text?.trim()) throw new Error("Didn't catch that — try again?");
      await sendText(sttData.text);
    } catch (err: any) {
      setError(err.message);
      setBusy(false);
    }
  }

  function playReply(text: string) {
    fetch("/api/tts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ characterId: id, text }),
    })
      .then((r) => (r.ok ? r.blob() : Promise.reject(r)))
      .then((blob) => {
        const url = URL.createObjectURL(blob);
        new Audio(url).play().catch(() => {});
      })
      .catch(() => {
        // Voice playback is best-effort — the text reply already rendered.
      });
  }

  if (!character) {
    return <main className="p-14 text-muted">Loading…</main>;
  }

  return (
    <main className="mx-auto max-w-2xl px-4 py-6 flex flex-col h-screen">
      <header className="flex items-center gap-3 pb-4 border-b border-white/5">
        <Link href="/" className="text-muted hover:text-mist text-sm">←</Link>
        {character.image_url && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={character.image_url}
            alt={character.name}
            className="h-10 w-10 rounded-full object-cover"
          />
        )}
        <div className="flex-1">
          <h1 className="font-display font-bold leading-tight">{character.name}</h1>
          <p className="text-xs text-muted">{character.tagline}</p>
        </div>
        <Link
          href={`/characters/${id}/call`}
          className="rounded-full bg-signal px-4 py-2 text-xs font-display font-semibold text-ink"
        >
          Call
        </Link>
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto py-4 space-y-3">
        {messages.length === 0 && (
          <p className="text-center text-muted text-sm mt-10">
            Say hi to {character.name} — by text or with the mic.
          </p>
        )}
        {messages.map((m) => (
          <ChatBubble key={m.id} message={m} />
        ))}
      </div>

      {error && (
        <p className="text-sm text-signal bg-signal/10 border border-signal/30 rounded-lg p-2 mb-2">
          {error}
        </p>
      )}

      <form
        onSubmit={(e) => {
          e.preventDefault();
          sendText(input);
        }}
        className="flex items-end gap-2 pb-4"
      >
        <VoiceButton onRecorded={handleVoiceMessage} disabled={busy} />
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={`Message ${character.name}…`}
          disabled={busy}
          className="input flex-1"
        />
        <button
          type="submit"
          disabled={busy || !input.trim()}
          className="h-12 rounded-full bg-wave px-5 font-display text-sm font-semibold text-ink disabled:opacity-50"
        >
          Send
        </button>
      </form>
    </main>
  );
}
