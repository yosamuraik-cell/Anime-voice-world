"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import Link from "next/link";

export default function NewCharacterPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [tagline, setTagline] = useState("");
  const [personality, setPersonality] = useState("");
  const [appearance, setAppearance] = useState("");
  const [voiceId, setVoiceId] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/characters", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          tagline,
          personality,
          appearance_prompt: appearance,
          voice_id: voiceId || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Something went wrong");
      router.push(`/characters/${data.character.id}/chat`);
    } catch (err: any) {
      setError(err.message);
      setSubmitting(false);
    }
  }

  return (
    <main className="mx-auto max-w-xl px-6 py-14">
      <Link href="/" className="text-sm text-muted hover:text-mist">
        ← Back to roster
      </Link>
      <h1 className="font-display text-3xl font-bold mt-4">New character</h1>
      <p className="mt-2 text-muted">
        Give them a name, a way of talking, and a look. The portrait is generated
        from your description.
      </p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-6">
        <Field label="Name">
          <input
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Yuki"
            className="input"
          />
        </Field>

        <Field label="Tagline" hint="One line shown on their card">
          <input
            value={tagline}
            onChange={(e) => setTagline(e.target.value)}
            placeholder="e.g. Sharp-tongued swordswoman with a soft spot for cats"
            className="input"
          />
        </Field>

        <Field
          label="Personality & speaking style"
          hint="How they talk, what they care about, quirks, tone. This drives every reply."
        >
          <textarea
            required
            value={personality}
            onChange={(e) => setPersonality(e.target.value)}
            rows={5}
            placeholder="e.g. Confident and teasing, speaks in short punchy sentences, secretly warm once she trusts someone, dislikes being underestimated..."
            className="input resize-none"
          />
        </Field>

        <Field
          label="Appearance"
          hint="Used to generate their portrait — hair, outfit, vibe"
        >
          <textarea
            value={appearance}
            onChange={(e) => setAppearance(e.target.value)}
            rows={3}
            placeholder="e.g. Silver bob haircut, red eyes, black-and-gold kimono jacket, calm expression"
            className="input resize-none"
          />
        </Field>

        <Field
          label="ElevenLabs voice ID (optional)"
          hint="Leave blank to use your default voice"
        >
          <input
            value={voiceId}
            onChange={(e) => setVoiceId(e.target.value)}
            placeholder="e.g. 21m00Tcm4TlvDq8ikWAM"
            className="input"
          />
        </Field>

        {error && (
          <p className="text-sm text-signal border border-signal/30 bg-signal/10 rounded-lg p-3">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-full bg-signal py-3 font-display font-semibold text-ink disabled:opacity-60"
        >
          {submitting ? "Bringing them to life…" : "Create character"}
        </button>
      </form>
    </main>
  );
}

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="font-display text-sm font-semibold">{label}</span>
      {hint && <span className="block text-xs text-muted mt-0.5">{hint}</span>}
      <div className="mt-2">{children}</div>
    </label>
  );
}
