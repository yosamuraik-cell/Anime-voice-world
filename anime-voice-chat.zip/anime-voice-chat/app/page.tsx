import Link from "next/link";
import { listCharacters } from "@/lib/db";
import CharacterCard from "@/components/CharacterCard";

export const dynamic = "force-dynamic";

export default function HomePage() {
  const characters = listCharacters();

  return (
    <main className="mx-auto max-w-5xl px-6 py-14">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="font-display text-4xl font-bold tracking-tight">
            Your roster
          </h1>
          <p className="mt-2 text-muted max-w-md">
            Characters you&apos;ve created. Message them by text, or call to talk out loud.
          </p>
        </div>
        <Link
          href="/characters/new"
          className="rounded-full bg-wave px-5 py-3 font-display text-sm font-semibold text-ink hover:brightness-110 transition-[filter]"
        >
          + New character
        </Link>
      </div>

      {characters.length === 0 ? (
        <div className="mt-16 rounded-panel border border-dashed border-white/10 p-12 text-center">
          <p className="font-display text-xl">No one&apos;s here yet.</p>
          <p className="mt-2 text-muted">
            Create your first character — give them a personality and a voice.
          </p>
          <Link
            href="/characters/new"
            className="mt-6 inline-block rounded-full bg-signal px-6 py-3 font-display text-sm font-semibold text-ink"
          >
            Create a character
          </Link>
        </div>
      ) : (
        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {characters.map((c, i) => (
            <CharacterCard character={c} index={i} key={c.id} />
          ))}
        </div>
      )}
    </main>
  );
}
