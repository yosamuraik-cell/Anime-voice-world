import { NextRequest, NextResponse } from "next/server";
import { speechToText } from "@/lib/providers";

export async function POST(req: NextRequest) {
  const form = await req.formData();
  const file = form.get("audio") as File | null;
  if (!file) {
    return NextResponse.json({ error: "audio file is required" }, { status: 400 });
  }

  const buffer = Buffer.from(await file.arrayBuffer());

  try {
    const text = await speechToText(buffer, file.type);
    return NextResponse.json({ text });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 502 });
  }
}
