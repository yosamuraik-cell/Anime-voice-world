import { NextRequest, NextResponse } from "next/server";
import { getCharacter } from "@/lib/db";
import { textToSpeech } from "@/lib/providers";

export async function POST(req: NextRequest) {
  const { characterId, text } = await req.json();
  if (!text) {
    return NextResponse.json({ error: "text is required" }, { status: 400 });
  }

  const character = characterId ? getCharacter(characterId) : undefined;

  try {
    const audio = await textToSpeech(text, character?.voice_id);
    return new NextResponse(audio, {
      headers: { "Content-Type": "audio/mpeg" },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 502 });
  }
}
