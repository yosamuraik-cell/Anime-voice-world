import { NextRequest, NextResponse } from "next/server";
import { v4 as uuid } from "uuid";
import { listCharacters, insertCharacter } from "@/lib/db";
import { generateCharacterImage } from "@/lib/providers";

export async function GET() {
  return NextResponse.json({ characters: listCharacters() });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { name, tagline, personality, voice_id, appearance_prompt } = body;

  if (!name || !personality) {
    return NextResponse.json(
      { error: "name and personality are required" },
      { status: 400 }
    );
  }

  let image_url: string | null = null;
  try {
    image_url = await generateCharacterImage(
      appearance_prompt || `${name}, ${tagline || personality}`
    );
  } catch (err: any) {
    // Character can still be created without an image if the image API fails.
    console.error("Image generation failed:", err.message);
  }

  const character = {
    id: uuid(),
    name,
    tagline: tagline || "",
    personality,
    voice_id: voice_id || null,
    image_url,
    created_at: new Date().toISOString(),
  };

  insertCharacter(character);
  return NextResponse.json({ character });
}
