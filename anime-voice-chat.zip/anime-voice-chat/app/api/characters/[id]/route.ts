import { NextRequest, NextResponse } from "next/server";
import { getCharacter, deleteCharacter, listMessages } from "@/lib/db";

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const character = getCharacter(params.id);
  if (!character) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  const messages = listMessages(params.id);
  return NextResponse.json({ character, messages });
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  deleteCharacter(params.id);
  return NextResponse.json({ ok: true });
}
