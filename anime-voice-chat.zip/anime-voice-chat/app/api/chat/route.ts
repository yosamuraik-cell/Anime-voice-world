import { NextRequest, NextResponse } from "next/server";
import { v4 as uuid } from "uuid";
import { getCharacter, insertMessage, listMessages } from "@/lib/db";
import { characterReply } from "@/lib/providers";

export async function POST(req: NextRequest) {
  const { characterId, text } = await req.json();
  if (!characterId || !text) {
    return NextResponse.json(
      { error: "characterId and text are required" },
      { status: 400 }
    );
  }

  const character = getCharacter(characterId);
  if (!character) {
    return NextResponse.json({ error: "Character not found" }, { status: 404 });
  }

  const history = listMessages(characterId).slice(-20); // keep prompts bounded

  const userMessage = {
    id: uuid(),
    character_id: characterId,
    role: "user" as const,
    content: text,
    created_at: new Date().toISOString(),
  };
  insertMessage(userMessage);

  let replyText: string;
  try {
    replyText = await characterReply(character.personality, history, text);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 502 });
  }

  const assistantMessage = {
    id: uuid(),
    character_id: characterId,
    role: "assistant" as const,
    content: replyText,
    created_at: new Date().toISOString(),
  };
  insertMessage(assistantMessage);

  return NextResponse.json({ reply: assistantMessage });
}
