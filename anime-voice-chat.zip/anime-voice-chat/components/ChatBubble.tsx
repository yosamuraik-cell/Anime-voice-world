import type { Message } from "@/lib/types";

export default function ChatBubble({ message }: { message: Message }) {
  const isUser = message.role === "user";
  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
          isUser
            ? "bg-signal text-ink rounded-br-sm"
            : "bg-panel2 text-mist rounded-bl-sm"
        }`}
      >
        {message.content}
      </div>
    </div>
  );
}
