import Link from "next/link";
import type { Character } from "@/lib/types";

const TAG_COLORS = ["bg-signal", "bg-wave", "bg-gold"];

export default function CharacterCard({
  character,
  index,
}: {
  character: Character;
  index: number;
}) {
  const tag = TAG_COLORS[index % TAG_COLORS.length];

  return (
    <div className="group relative rounded-panel bg-panel overflow-hidden border border-white/5 transition-transform duration-200 hover:-translate-y-1">
      <div className="portrait-mask relative h-56 bg-panel2">
        {character.image_url ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={character.image_url}
            alt={character.name}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-muted text-sm">
            no portrait yet
          </div>
        )}
        <span
          className={`absolute top-3 left-3 ${tag} h-2.5 w-2.5 rounded-full`}
          aria-hidden
        />
      </div>

      <div className="p-4">
        <h3 className="font-display text-lg leading-tight">{character.name}</h3>
        <p className="mt-1 text-sm text-muted line-clamp-2">{character.tagline}</p>

        <div className="mt-4 flex gap-2">
          <Link
            href={`/characters/${character.id}/chat`}
            className="flex-1 text-center rounded-full bg-panel2 py-2 text-sm font-medium hover:bg-white/10 transition-colors"
          >
            Message
          </Link>
          <Link
            href={`/characters/${character.id}/call`}
            className="flex-1 text-center rounded-full bg-signal py-2 text-sm font-medium text-ink hover:brightness-110 transition-[filter]"
          >
            Call
          </Link>
        </div>
      </div>
    </div>
  );
}
