import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#131320",
        panel: "#1B1B2C",
        panel2: "#232338",
        mist: "#EDEAF6",
        muted: "#9E9AB8",
        signal: "#FF3D81",
        wave: "#28E0C7",
        gold: "#FFC857",
      },
      fontFamily: {
        display: ["var(--font-display)"],
        body: ["var(--font-body)"],
      },
      borderRadius: {
        panel: "22px",
      },
    },
  },
  plugins: [],
};

export default config;
