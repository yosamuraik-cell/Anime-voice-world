# Roster — anime voice companions

A small Next.js app where you create anime characters (personality + generated
portrait) and talk to them by text or by voice call, similar to Character.AI.

## What's included

- **Character creation** — name, personality/speaking-style prompt, appearance
  prompt. The portrait is generated automatically via the OpenAI Images API.
- **Text + voice chat** — a normal chat thread; you can type or record a
  voice message, which is transcribed and sent as a normal turn. Replies are
  read aloud automatically.
- **Voice calling** — a push-to-talk call screen: hold/tap the mic, speak,
  release. Your speech is transcribed → sent to the character's chat model →
  the reply is synthesized back to audio and played.
- **Local persistence** — characters and message history are stored in a
  SQLite file on disk (`./data/app.db`), so nothing is lost between restarts.

All third-party API calls happen **server-side only** (in `app/api/*` route
handlers and `lib/providers.ts`), so your API keys never reach the browser.

## Providers used (all swappable)

| Purpose             | Default provider        | File                    |
|---------------------|--------------------------|--------------------------|
| Character portraits | OpenAI Images (`gpt-image-1`) | `lib/providers.ts` → `generateCharacterImage` |
| Character chat       | Anthropic Claude (or OpenAI, via `CHAT_PROVIDER`) | `lib/providers.ts` → `characterReply` |
| Speech-to-text        | ElevenLabs Scribe        | `lib/providers.ts` → `speechToText` |
| Text-to-speech        | ElevenLabs TTS           | `lib/providers.ts` → `textToSpeech` |

Each character can optionally have its own `voice_id` (an ElevenLabs voice
ID) so different characters sound different. Leave it blank to use
`ELEVENLABS_DEFAULT_VOICE_ID`.

## Setup

```bash
npm install
cp .env.example .env.local
# then fill in your API keys in .env.local
npm run dev
```

Open http://localhost:3000. On first run, `data/app.db` is created
automatically.

### Required keys

- `OPENAI_API_KEY` — for portrait generation
- `ANTHROPIC_API_KEY` (or `OPENAI_API_KEY` + `CHAT_PROVIDER=openai`) — for
  character replies
- `ELEVENLABS_API_KEY` — for voice input/output

You don't need all three to get something running — image generation
failures are non-fatal (the character is created without a portrait), but
chat and voice do need their respective keys set.

## Project structure

```
app/
  page.tsx                     Roster / dashboard
  characters/new/page.tsx      Character creation form
  characters/[id]/chat/page.tsx  Text + voice chat
  characters/[id]/call/page.tsx  Voice call screen
  api/characters/              CRUD for characters
  api/chat/                    Character reply endpoint (also persists history)
  api/stt/                     Speech-to-text endpoint
  api/tts/                     Text-to-speech endpoint
lib/
  db.ts          SQLite schema + queries (better-sqlite3)
  providers.ts   All third-party API calls, in one place
  types.ts       Shared TypeScript types
components/
  CharacterCard.tsx, ChatBubble.tsx, VoiceButton.tsx
```

## Notes on taking this further

- **Storage**: portraits are stored as base64 data URLs directly in SQLite,
  which is fine for a prototype but will bloat the DB. For production, upload
  generated images to blob storage (S3, Cloudflare R2, etc.) and store the
  URL instead.
- **Database**: swap SQLite for Postgres (e.g. via Prisma or Drizzle) once
  you need multiple users/devices — SQLite here is single-file and fine for
  one person running it locally or on a single small server.
- **Auth**: there's no login system — anyone with access to the deployed URL
  can see all characters. Add auth (e.g. NextAuth, Clerk) before deploying
  publicly.
- **Real-time calling**: the call screen is push-to-talk (record → send →
  play reply) rather than a fully open mic with interruption handling. A
  true "always-listening" call (like a phone call) needs streaming STT and
  voice-activity detection — ElevenLabs and other providers offer
  WebSocket-based streaming APIs for this if you want to upgrade it.
- **Character content**: this app puts no limits on what personalities you
  write. If you publish this beyond personal use, you're responsible for
  moderating character descriptions and generated content per your
  jurisdiction's rules and the terms of the providers you plug in (OpenAI,
  Anthropic, ElevenLabs all have their own usage policies, especially around
  likenesses of real people and minors).
