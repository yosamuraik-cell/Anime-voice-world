/**
 * All calls to third-party AI APIs live here, server-side only, so that
 * API keys never reach the browser. Each function is intentionally small
 * and swappable — if you want a different image/chat/voice provider,
 * change the implementation, not the callers.
 */

import type { Message } from "./types";

// ---------- Image generation (character avatars) ----------
// Default: OpenAI images/generations. Swap for Stability AI etc. if you prefer.
export async function generateCharacterImage(prompt: string): Promise<string> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY is not set");

  const res = await fetch("https://api.openai.com/v1/images/generations", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "gpt-image-1",
      prompt: `anime character portrait, clean line art, vibrant colors, upper body, plain background: ${prompt}`,
      size: "1024x1024",
      n: 1,
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Image generation failed: ${res.status} ${text}`);
  }

  const data = await res.json();
  const b64 = data.data?.[0]?.b64_json;
  if (!b64) throw new Error("Image generation returned no image data");
  return `data:image/png;base64,${b64}`;
}

// ---------- Character chat (personality-driven replies) ----------
export async function characterReply(
  personality: string,
  history: Message[],
  userText: string
): Promise<string> {
  const provider = process.env.CHAT_PROVIDER || "anthropic";
  const systemPrompt = `You are roleplaying as an anime character. Stay fully in character.
Personality and speaking style:
${personality}

Keep replies conversational and voice-friendly: short paragraphs, no stage directions in asterisks, no markdown. This is a spoken conversation, not a written one.`;

  const turns = [
    ...history.map((m) => ({ role: m.role, content: m.content })),
    { role: "user" as const, content: userText },
  ];

  if (provider === "openai") {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) throw new Error("OPENAI_API_KEY is not set");
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: process.env.CHAT_MODEL || "gpt-4o-mini",
        messages: [{ role: "system", content: systemPrompt }, ...turns],
      }),
    });
    if (!res.ok) throw new Error(`Chat failed: ${res.status} ${await res.text()}`);
    const data = await res.json();
    return data.choices?.[0]?.message?.content?.trim() || "...";
  }

  // Default: Anthropic
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) throw new Error("ANTHROPIC_API_KEY is not set");
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: process.env.CHAT_MODEL || "claude-sonnet-4-6",
      max_tokens: 500,
      system: systemPrompt,
      messages: turns,
    }),
  });
  if (!res.ok) throw new Error(`Chat failed: ${res.status} ${await res.text()}`);
  const data = await res.json();
  const textBlock = data.content?.find((c: any) => c.type === "text");
  return textBlock?.text?.trim() || "...";
}

// ---------- Speech-to-text ----------
// Default: ElevenLabs Scribe. Accepts a raw audio Blob/Buffer from the browser recorder.
export async function speechToText(audio: Buffer, mimeType: string): Promise<string> {
  const apiKey = process.env.ELEVENLABS_API_KEY;
  if (!apiKey) throw new Error("ELEVENLABS_API_KEY is not set");

  const form = new FormData();
  form.append("model_id", "scribe_v1");
  form.append(
    "file",
    new Blob([audio], { type: mimeType || "audio/webm" }),
    "audio.webm"
  );

  const res = await fetch("https://api.elevenlabs.io/v1/speech-to-text", {
    method: "POST",
    headers: { "xi-api-key": apiKey },
    body: form,
  });

  if (!res.ok) throw new Error(`STT failed: ${res.status} ${await res.text()}`);
  const data = await res.json();
  return data.text || "";
}

// ---------- Text-to-speech ----------
// Default: ElevenLabs TTS. Returns raw audio bytes (mp3).
export async function textToSpeech(text: string, voiceId?: string | null): Promise<Buffer> {
  const apiKey = process.env.ELEVENLABS_API_KEY;
  if (!apiKey) throw new Error("ELEVENLABS_API_KEY is not set");

  const voice =
    voiceId || process.env.ELEVENLABS_DEFAULT_VOICE_ID || "21m00Tcm4TlvDq8ikWAM";

  const res = await fetch(
    `https://api.elevenlabs.io/v1/text-to-speech/${voice}`,
    {
      method: "POST",
      headers: {
        "xi-api-key": apiKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        text,
        model_id: "eleven_multilingual_v2",
        voice_settings: { stability: 0.4, similarity_boost: 0.8 },
      }),
    }
  );

  if (!res.ok) throw new Error(`TTS failed: ${res.status} ${await res.text()}`);
  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}
