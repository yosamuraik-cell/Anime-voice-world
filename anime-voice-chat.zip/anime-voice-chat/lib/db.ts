import Database from "better-sqlite3";
import fs from "fs";
import path from "path";
import type { Character, Message } from "./types";

const DB_PATH = process.env.DATABASE_PATH || "./data/app.db";

// Ensure the data directory exists before opening the file.
const dir = path.dirname(DB_PATH);
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

// Reuse a single connection across hot reloads in dev.
declare global {
  // eslint-disable-next-line no-var
  var __avc_db: Database.Database | undefined;
}

const db = global.__avc_db ?? new Database(DB_PATH);
if (process.env.NODE_ENV !== "production") global.__avc_db = db;

db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS characters (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    tagline TEXT NOT NULL DEFAULT '',
    personality TEXT NOT NULL,
    voice_id TEXT,
    image_url TEXT,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    character_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (character_id) REFERENCES characters(id) ON DELETE CASCADE
  );
`);

export function listCharacters(): Character[] {
  return db
    .prepare("SELECT * FROM characters ORDER BY created_at DESC")
    .all() as Character[];
}

export function getCharacter(id: string): Character | undefined {
  return db.prepare("SELECT * FROM characters WHERE id = ?").get(id) as
    | Character
    | undefined;
}

export function insertCharacter(c: Character) {
  db.prepare(
    `INSERT INTO characters (id, name, tagline, personality, voice_id, image_url, created_at)
     VALUES (@id, @name, @tagline, @personality, @voice_id, @image_url, @created_at)`
  ).run(c);
}

export function deleteCharacter(id: string) {
  db.prepare("DELETE FROM messages WHERE character_id = ?").run(id);
  db.prepare("DELETE FROM characters WHERE id = ?").run(id);
}

export function listMessages(characterId: string): Message[] {
  return db
    .prepare(
      "SELECT * FROM messages WHERE character_id = ? ORDER BY created_at ASC"
    )
    .all(characterId) as Message[];
}

export function insertMessage(m: Message) {
  db.prepare(
    `INSERT INTO messages (id, character_id, role, content, created_at)
     VALUES (@id, @character_id, @role, @content, @created_at)`
  ).run(m);
}

export default db;
