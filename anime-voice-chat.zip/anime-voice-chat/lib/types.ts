export type Character = {
  id: string;
  name: string;
  tagline: string;
  personality: string; // system prompt describing how the character talks/acts
  voice_id: string | null;
  image_url: string | null; // data: URL
  created_at: string;
};

export type Message = {
  id: string;
  character_id: string;
  role: "user" | "assistant";
  content: string;
  created_at: string;
};
